import React, { useEffect, useState } from 'react'
import axios from '../../apis/api'
import Loader from '../loader/loader'
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';
import { useNavigate } from 'react-router-dom'
import TablePagination from '@mui/material/TablePagination';
import './munisTable.css'


export default function MunisTable() {
    const navigate = useNavigate()

    const [responseData, setResponseData] = useState([])
    const [overall, setOverall] = useState("")

    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(15);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 15));
        setPage(0);
    };

    const getData = async () => {
        try {
            axios({
                url: `https://munis.unired.uz/api/v2/blanks/?page=${page+1}`,
                method: "get",
                headers: {
                    Authorization: "Bearer e08c3f7ac9fba4d602b0d40c3fe3322207cb1c62",
                },
            }).then(res => {
                setResponseData(res.data.results)
                setOverall(Math.ceil(res.data.count))
            }).catch(err => console.log(err))
        } catch (error) {
            console.log(error)
        }
    }
    console.log(overall)
    useEffect(() => {
        getData()
    }, [page])

    const chosenTransaction = (e, id) => {
        e.preventDefault()
        navigate(`/munis/${id}`)
    }

    return (
        <div className='humoTable'>
            {/* <DataGrid rows={rows} columns={columns} /> */}
            <TablePagination
                component="div"
                count={overall}
                page={page}
                onPageChange={handleChangePage}
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
            {responseData.length > 0 ? (<table className="table">
                <thead>
                    <tr className='py-5 bg-primary text-white'>
                        <th scope="col">BID </th>
                        <th>TID</th>
                        <th>SID</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Status</th>
                        <th scope="col">Date</th>
                        <th scope="col">Time</th>
                    </tr>
                </thead>
                <tbody>
                    {responseData.map(child => (
                        <tr key={child.sysinfo.bid} className="py-3">
                            <td onClick={(e) => chosenTransaction(e, child.id)}>{child.sysinfo.bid}</td>
                            <td>{child.sysinfo.tid}</td>
                            <td>{child.sysinfo.sid}</td>
                            <td>{child.amount.value}</td>
                            <td>{child.confirm.message}</td>
                            <td>{child.sysinfo.data}</td>
                            <td>{child.sysinfo.time}</td>
                        </tr>
                    ))}
                </tbody>

                <TablePagination
                    component="div"
                    count={overall}
                    page={page}
                    onPageChange={handleChangePage}
                    rowsPerPage={rowsPerPage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />

            </table>
            ) : (<Loader />)}
        </div>
    )
}
