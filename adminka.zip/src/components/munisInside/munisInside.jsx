import React, { useContext, useEffect, useState } from 'react'
import StateContext from '../../context/useContext'
import { useParams } from 'react-router-dom';
import { Container, Col, Row } from 'react-bootstrap';
import { Home } from '@mui/icons-material';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';
import { CornerLeftDown, CornerRightUp, CreditCard, } from 'react-feather';
import SyncLockIcon from '@mui/icons-material/SyncLock';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import axios from 'axios'
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Modal from '@mui/material/Modal';
import Loader from '../loader/loader';
import jsPDF from 'jspdf'
import './munisInside.css'
import pechat from '../../assets//images/pechatPro.png'


const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: "90%",
    height: "80vh",
    overflowY: "scroll",
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
    borderRadius: "10px",
};


export default function MunisINside() {
    const { navStretch } = useContext(StateContext)
    const [responseData, setResponseData] = useState("")
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);


    var { id } = useParams()

    useEffect(() => {

        axios({
            url: `https://munis.unired.uz/api/v2/blanks/${id}`,
            method: "get",
            headers: {
                Authorization: "Bearer e08c3f7ac9fba4d602b0d40c3fe3322207cb1c62",
            },
        }).then(res => {
            setResponseData(res.data)
            console.log(res)
        }).catch(err => console.log(err.message))

    }, [id])


    const generatePDF = () => {
        handleClose()
        var doc = new jsPDF("p", "pt", "a4")
        doc.html(document.querySelector("#mainContent"), {
            callback: function (pdf) {
                pdf.save(`transaction${responseData.sysinfo.bid}.pdf`)
            }
        })
    }
    return (
        <div className={navStretch ? "ml-285" : "ml-90"}>


            <Container className={navStretch?"humoinside":"humoinside px-0"}>
                <div className="header d-flex justify-content-between align-items-center">
                    <h3 className="title mainColor">
                        Transfers
                    </h3>
                    <div className="breadcrumbs d-flex align-items-center mainColor">
                        <p className='pointer d-flex align-items-center'><Home /></p>
                        <p className='bold'>/Munis</p>
                        <p>/Payments</p>
                        <p>/Transaction</p>
                    </div>
                </div>
                {responseData ? (
                    <>
                        <h4 className='mt-4  mb-3 mainColor bolder'> <span className='bold text-dark'> Transaction BID: </span>{responseData.sysinfo.bid}</h4>

                        <Row className='mb-4'>
                            <Col md="3">
                                <div className="boxshadow bg-white p-3 inside-item">
                                    <div className='icon-box'>
                                        <CornerRightUp className='mainColor' />
                                    </div>
                                    <div>
                                        <p className='title'>Payer account:</p>
                                        <p className='mainDesc mainColor small-text'>{responseData.payer.account}</p>
                                    </div>
                                </div>
                            </Col>
                            <Col md="3">
                                <div className="boxshadow bg-white p-3 inside-item">
                                    <div className='icon-box'>
                                        <CornerLeftDown className='mainColor' />
                                    </div>
                                    <div>
                                        <p className='title'>Payee account:</p>
                                        <p className='mainDesc mainColor small-text'>{responseData.payee.account}</p>
                                    </div>
                                </div>
                            </Col>
                            <Col md="3">
                                <div className="boxshadow bg-white p-3 inside-item">
                                    <div className='icon-box'>
                                        <SyncLockIcon className='mainColor' />
                                    </div>
                                    <div>
                                        <p className='title'>TID:</p>
                                        <p className='mainDesc mainColor small-text'>{responseData.sysinfo.tid ? responseData.sysinfo.tid : "N/A"}</p>
                                    </div>
                                </div>
                            </Col>
                            <Col md="3">
                                <div className="boxshadow bg-white p-3 inside-item">
                                    <div className='icon-box'>
                                        <SyncLockIcon className='mainColor' />
                                    </div>
                                    <div>
                                        <p className='title'>SID:</p>
                                        <p className='mainDesc mainColor small-text'>{responseData.sysinfo.sid ? responseData.sysinfo.sid : "N/A"}</p>
                                    </div>
                                </div>
                            </Col>

                        </Row>
                        <Row className='mb-5'>
                            <Col md="3">
                                <div className="boxshadow bg-white p-3 inside-item">
                                    <div className='icon-box'>
                                        <CreditCard className='mainColor' />
                                    </div>
                                    <div>
                                        <p className='title'>Amount:</p>
                                        <p className='mainDesc mainColor'>{responseData.amount.value != 0 ? responseData.amount.value : "N/A"}</p>
                                    </div>
                                </div>
                            </Col>
                            <Col md="3">
                                <div className={`boxshadow p-3 inside-item bg-white`}>
                                    <div className='icon-box'>
                                        <EventAvailableIcon className='mainColor' />
                                    </div>
                                    <div>
                                        <p className='title'>Status:</p>
                                        <p className='mainDesc mainColor'>{responseData.confirm.message}</p>
                                    </div>
                                </div>
                            </Col>
                            <Col md="3">
                                <div className="boxshadow bg-white p-3 inside-item">
                                    <div className='icon-box'>
                                        <CalendarMonthIcon className='mainColor' />
                                    </div>
                                    <div>
                                        <p className='title'>Date:</p>
                                        <p className='mainDesc mainColor'>{responseData.sysinfo.data}</p>
                                    </div>
                                </div>
                            </Col>
                            <Col md="3">
                                <div className="boxshadow bg-white p-3 inside-item">
                                    <div className='icon-box'>
                                        <AccessTimeIcon className='mainColor' />
                                    </div>
                                    <div>
                                        <p className='title'>Time:</p>
                                        <p className='mainDesc mainColor'>{responseData.sysinfo.time}</p>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                        <Row className='roww justify-content-end'>
                            <Col md="2">
                                <Button onClick={handleOpen} className='cheque w-100'>
                                    Get Cheque
                                </Button>
                            </Col>
                            <Modal
                                open={open}
                                onClose={handleClose}
                                aria-labelledby="modal-modal-title"
                                aria-describedby="modal-modal-description"
                            >
                                <Box id="pdfContent" sx={style}>
                                    <div id="mainContent">
                                        <p>bid: <span>{responseData.sysinfo.bid} </span></p>
                                        <p>Payer: <span>{responseData.payer.account}</span></p>
                                        <p>Receiver: <span>{responseData.payee.account}</span></p>
                                        <p>Amount of transaction: <span>{responseData.amount.value != 0 ? responseData.amount.value : "N/A"} so'm</span></p>
                                        <p>Date: <span>{responseData.sysinfo.data}</span></p>
                                        <p>Time: <span>{responseData.sysinfo.time}</span></p>

                                        <div className="credentials">
                                            <p>Mr Jack Gibson</p>
                                            <img src={pechat} alt="..." />
                                        </div>
                                    </div>
                                    <Button onClick={generatePDF} className='cheque w-100'>
                                        Get Cheque
                                    </Button>

                                </Box>
                            </Modal>
                        </Row></>) : (<Loader />)}
            </Container>

        </div>
    )
}
