import React, { useEffect, useState } from "react";
import "./App.css";
import Navbar from "./layout/navbar/navbar";
import Sidebar from "./layout/sidebar/sidebar";
import StateContext from "./context/useContext";
import Homepage from "./pages/Homepage/homepage";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import ScrollToTop from "react-scroll-to-top";
import HumoCard from "./components/humoCard/HumoCard";
import HumoINside from "./components/humoInside/HumoInside";
import Munis from "./components/munis/Munis";
import MunisINside from "./components/munisInside/munisInside";
import Uzcard from "./components/uzcard/uzcard";
import ExampleFather from "./components/example/exampleFather";
import axios from "./apis/api";

function App() {
  const [navStretch, setnavStretch] = useState(false);
  const [navDominant, setnavDominant] = useState(false);
  useEffect(() => {
    try {
      axios
        .get(
          "http://192.168.202.38.8000/api/v1/oldSvgatePayments/?page=1",
          // { crossDomain: true },
          {
            headers: {
              Authorization: "Bearer fb064031625968a0a2348dd0fa5d453e10b48744",
            },
          }
        )
        .then((res) => {
          console.log(res);
        })
        .catch((err) => {console.log("wrongie")
        console.log(err)
      });
    } catch (error) {
      console.log(error);
    }
  }, []);
  return (
    <div className="App">
      <StateContext.Provider
        value={{ navStretch, setnavStretch, navDominant, setnavDominant }}
      >
        <BrowserRouter>
          <Sidebar />
          <Navbar />
          <Routes>
            <Route path="/" element={<Homepage />} />
            <Route path="/uzcard" element={<Uzcard />} />
            <Route path="/pdf" element={<ExampleFather />} />
            <Route path="/humo" element={<HumoCard />} />
            <Route path="/humo/:id" element={<HumoINside />} />
            <Route path="/munis" element={<Munis />} />
            <Route path="/munis/:id" element={<MunisINside />} />
          </Routes>
        </BrowserRouter>
        <ScrollToTop className="scrollToTop" smooth />
      </StateContext.Provider>
    </div>
  );
}

export default App;
